package com.zybooks.inventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class LoginDAO extends SQLiteOpenHelper {

    public static final String LOGIN_TABLE = "LOGIN_TABLE";
    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_USERNAME = "USERNAME";
    public static final String COLUMN_PW = "PW";

    public LoginDAO(@Nullable Context context) {
        super(context, "login.db", null, 1);
    }

    // Create new database
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + LOGIN_TABLE + " (" + COLUMN_USERNAME + " TEXT, " + COLUMN_PW + " TEXT)";

        db.execSQL(createTable);
    }

    // Triggered when database is updated
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean addOne(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_USERNAME, user.getUsername());
        cv.put(COLUMN_PW, user.getPassword());

        long insert = db.insert(LOGIN_TABLE, null, cv);

        if (insert == -1) {
            return false;
        } else {
            return true;
        }
    }

    public boolean verifyUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT " + COLUMN_USERNAME + ", " + COLUMN_PW + " FROM " + LOGIN_TABLE
                + " WHERE " + COLUMN_USERNAME + "='" + username + "' AND " + COLUMN_PW + "='" + password + "'";

        Cursor cursor = db.rawQuery(sql, null);

        if (cursor.moveToFirst()) {
            return true;
        } else {
            return false;
        }
    }
}
