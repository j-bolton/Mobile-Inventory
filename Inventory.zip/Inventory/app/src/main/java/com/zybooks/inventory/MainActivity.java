package com.zybooks.inventory;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    Button buttonAddItem, buttonClear;
    ImageButton buttonNotification, buttonIncrease, buttonDecrease, buttonDelete;
    EditText editTextItemName, editTextQuantity, editTextItemLocation;
    ListView listViewItems;
    Item selectedItem;
    String lowStockMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonClear = findViewById(R.id.buttonClear);
        buttonNotification = findViewById(R.id.buttonNotification);
        buttonIncrease = findViewById(R.id.buttonIncrease);
        buttonDecrease = findViewById(R.id.buttonDecrease);
        buttonDelete = findViewById(R.id.buttonDelete);
        editTextItemName = findViewById(R.id.editTextItemName);
        editTextQuantity = findViewById(R.id.editTextItemNumber);
        editTextItemLocation = findViewById(R.id.editTextItemLocation);
        listViewItems = findViewById(R.id.listViewItems);

        ItemDAO dao = new ItemDAO(MainActivity.this);
        List<Item> allItems = dao.getAll();
        final ArrayAdapter[] arrayAdapter = {new ArrayAdapter<Item>(MainActivity.this, android.R.layout.simple_list_item_single_choice, allItems)};
        listViewItems.setAdapter(arrayAdapter[0]);
        listViewItems.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        // Click listeners for all buttons
        buttonAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Item item;

                // Creates new item object if all fields are filled
                try {
                    item = new Item(-1, editTextItemName.getText().toString(), editTextItemLocation.getText().toString(),
                            Integer.parseInt(editTextQuantity.getText().toString()));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Error: Item name, number, and location required", Toast.LENGTH_LONG).show();
                    item = new Item(-1, "null", "null", -1);
                }
                ;

                ItemDAO dao = new ItemDAO(MainActivity.this);
                dao.addOne(item);

                // Refresh list after adding item
                arrayAdapter[0] = new ArrayAdapter<Item>(MainActivity.this, android.R.layout.simple_list_item_single_choice, dao.getAll());
                listViewItems.setAdapter(arrayAdapter[0]);

            }
        });

        buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextItemName.getText().clear();
                editTextQuantity.getText().clear();
                editTextItemLocation.getText().clear();
            }
        });

        buttonNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PermissionsActivity.class);
                startActivity(intent);
            }
        });

        buttonIncrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dao.updateQuantity(selectedItem, 1);

                // Refresh list after deleting item
                arrayAdapter[0] = new ArrayAdapter<Item>(MainActivity.this, android.R.layout.simple_list_item_single_choice, dao.getAll());
                listViewItems.setAdapter(arrayAdapter[0]);
            }
        });

        buttonDecrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dao.updateQuantity(selectedItem, -1);

                // Message sent if item reaches zero quantity
                if (selectedItem.getItemQuantity() < 1) {
                    lowStockMessage = selectedItem.getItemName() + " is out of stock.";
                    if (PermissionsActivity.phoneNum != null) {
                        sendSMSMessage();
                    }
                }

                // Refresh list after decreasing item
                arrayAdapter[0] = new ArrayAdapter<Item>(MainActivity.this, android.R.layout.simple_list_item_single_choice, dao.getAll());
                listViewItems.setAdapter(arrayAdapter[0]);
            }
        });

        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Delete selected item from the list
                dao.deleteOne(selectedItem);

                // Hide buttons after deleting selection
                buttonIncrease.setVisibility(View.INVISIBLE);
                buttonDecrease.setVisibility(View.INVISIBLE);
                buttonDelete.setVisibility(View.INVISIBLE);

                // Refresh list after deleting item
                arrayAdapter[0] = new ArrayAdapter<Item>(MainActivity.this, android.R.layout.simple_list_item_single_choice, dao.getAll());
                listViewItems.setAdapter(arrayAdapter[0]);
            }
        });

        // Determines which item is selected from the list
        listViewItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                selectedItem = (Item) parent.getItemAtPosition(position);

                // Make buttons visible only once an item is selected
                buttonIncrease.setVisibility(View.VISIBLE);
                buttonDecrease.setVisibility(View.VISIBLE);
                buttonDelete.setVisibility(View.VISIBLE);
            }
        });

    }

    protected void sendSMSMessage() {

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        PermissionsActivity.PERMISSIONS_REQUEST_SEND_SMS);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PermissionsActivity.PERMISSIONS_REQUEST_SEND_SMS: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(PermissionsActivity.phoneNum, null, lowStockMessage, null, null);
                    Toast.makeText(getApplicationContext(), "SMS sent.",
                            Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(),
                            "SMS failed, please try again.", Toast.LENGTH_LONG).show();
                    return;
                }
            }
        }
    }
}