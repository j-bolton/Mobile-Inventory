package com.zybooks.inventory;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class PermissionsActivity extends AppCompatActivity {

    public static final int PERMISSIONS_REQUEST_SEND_SMS = 0;
    public static String phoneNum;
    public static SmsManager smsManager;
    private Button buttonEnable, buttonCancel;
    private TextView editTextPhoneNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permissions);

        buttonEnable = findViewById(R.id.buttonEnable);
        buttonCancel = findViewById(R.id.buttonBack);
        editTextPhoneNum = findViewById(R.id.editTextPhone);
        phoneNum = "";


        buttonEnable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editTextPhoneNum.getText().length() == 10) {
                    checkPermission(Manifest.permission.SEND_SMS, PERMISSIONS_REQUEST_SEND_SMS);
                    phoneNum = editTextPhoneNum.getText().toString();
                } else {
                    Toast.makeText(PermissionsActivity.this, "Please enter a 10 digit phone number", Toast.LENGTH_LONG).show();
                }
            }
        });

        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PermissionsActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }


    // Function to check and request permission.
    public void checkPermission(String permission, int requestCode) {
        if (ContextCompat.checkSelfPermission(PermissionsActivity.this, permission) == PackageManager.PERMISSION_DENIED) {

            // Requesting the permission
            ActivityCompat.requestPermissions(PermissionsActivity.this, new String[]{permission}, requestCode);
        } else {
            // Do nothing
        }
    }


}