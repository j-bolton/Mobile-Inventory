package com.zybooks.inventory;

public class Item {

    private String itemName, itemLocation;
    private int id;
    private int itemQuantity;

    // Constructors
    public Item() {
    }

    public Item(int id, String itemName, String itemLocation, int itemQuantity) {
        this.itemName = itemName;
        this.itemLocation = itemLocation;
        this.id = id;
        this.itemQuantity = itemQuantity;
    }

    // Getters and setters
    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemLocation() {
        return itemLocation;
    }

    public void setItemLocation(String itemLocation) {
        this.itemLocation = itemLocation;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getItemQuantity() {
        return itemQuantity;
    }

    public void setItemQuantity(int itemQuantity) {
        this.itemQuantity = itemQuantity;
    }

    @Override
    public String toString() {
        return "Item: " + itemName +
                " | Quantity: " + itemQuantity +
                " | Location: " + itemLocation;
    }
}
