package com.zybooks.inventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class ItemDAO extends SQLiteOpenHelper {

    public static final String INVENTORY_TABLE = "INVENTORY_TABLE";
    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_ITEM_NAME = "ITEM_NAME";
    public static final String COLUMN_ITEM_QUANTITY = "ITEM_QUANTITY";
    public static final String COLUMN_ITEM_LOCATION = "ITEM_LOCATION";

    public ItemDAO(@Nullable Context context) {
        super(context, "inventory.db", null, 1);
    }

    // Create new database
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + INVENTORY_TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_ITEM_NAME + " TEXT, " + COLUMN_ITEM_QUANTITY + " INTEGER, " + COLUMN_ITEM_LOCATION + " TEXT)";

        db.execSQL(createTable);
    }

    // Triggered when database version is updated
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean addOne(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_ITEM_NAME, item.getItemName());
        cv.put(COLUMN_ITEM_QUANTITY, item.getItemQuantity());
        cv.put(COLUMN_ITEM_LOCATION, item.getItemLocation());

        long insert = db.insert(INVENTORY_TABLE, null, cv);

        if (insert == -1) {
            return false;
        } else {
            return true;
        }
    }

    public boolean deleteOne(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "DELETE FROM " + INVENTORY_TABLE + " WHERE " + COLUMN_ID +
                " = " + item.getId();

        Cursor cursor = db.rawQuery(sql, null);

        if (cursor.moveToFirst()) {
            return true;
        } else {
            return false;
        }

    }

    public boolean updateQuantity(Item item, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "UPDATE " + INVENTORY_TABLE + " SET " + COLUMN_ITEM_QUANTITY + " = "
                + COLUMN_ITEM_QUANTITY + " + " + quantity + " WHERE " +
                COLUMN_ID + " = " + item.getId();

        Cursor cursor = db.rawQuery(sql, null);

        if (cursor.moveToFirst()) {
            return true;
        } else {
            return false;
        }

    }

    public List<Item> getAll() {

        List<Item> returnList = new ArrayList<>();

        String sql = "SELECT * FROM " + INVENTORY_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();

        // Query database for all items
        Cursor cursor = db.rawQuery(sql, null);

        if (cursor.moveToFirst()) {
            // Iterate through cursor, creating new items in returnList for each line
            do {
                int id = cursor.getInt(0);
                String itemName = cursor.getString(1);
                String itemLocation = cursor.getString(3);
                int itemQuantity = cursor.getInt(2);

                Item item = new Item(id, itemName, itemLocation, itemQuantity);
                returnList.add(item);

            } while (cursor.moveToNext());
        } else {
            // Do nothing
        }

        cursor.close();
        db.close();

        return returnList;
    }

}
